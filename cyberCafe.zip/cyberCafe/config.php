<?php
include 'class/database.php';

$base_url = 'http://localhost/cyberCafe/';

?>
